# jp2_remediator

README for the module to validate jp2images

https://pypi.org/project/jp2_remediator/0.0.1/

## Installation

```bash
pip install jp2_remediator
python3 -m pip install jp2_remediator

pip install jp2_remediator==0.0.1
```